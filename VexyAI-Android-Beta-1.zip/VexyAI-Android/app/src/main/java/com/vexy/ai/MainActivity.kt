package com.vexy.ai

import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

private val Background = Color(0xFF090B12)
private val Panel = Color(0xFF151925)
private val Accent = Color(0xFF9D6BFF)
private val Mint = Color(0xFF5AF0C5)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { VexyApp() }
    }
}

@Composable
private fun VexyApp() {
    var videoUri by remember { mutableStateOf<Uri?>(null) }
    var audioUri by remember { mutableStateOf<Uri?>(null) }
    var duration by remember { mutableStateOf("15 soniya") }
    var style by remember { mutableStateOf("PHONK") }
    var prompt by remember { mutableStateOf("") }
    var status by remember { mutableStateOf("Video va musiqa tanlang — loyiha sozlamalari shu yerda.") }

    val videoPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        videoUri = uri
        if (uri != null) status = "Video tanlandi. Endi musiqa tanlang."
    }
    val audioPicker = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        audioUri = uri
        if (uri != null) status = "Musiqa tanlandi. Edit sozlamalarini tanlang."
    }

    MaterialTheme(
        colorScheme = darkColorScheme(
            primary = Accent,
            secondary = Mint,
            background = Background,
            surface = Panel
        )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(listOf(Color(0xFF17132B), Background, Background))
                )
                .verticalScroll(rememberScrollState())
                .padding(18.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text("VEXY AI", fontSize = 30.sp, fontWeight = FontWeight.Black, color = Color.White)
                    Text("BEAT-SYNC VIDEO EDITOR", fontSize = 11.sp, color = Mint, letterSpacing = 2.sp)
                }
                Surface(color = Color(0xFF25352F), shape = RoundedCornerShape(50)) {
                    Text("FREE BETA", modifier = Modifier.padding(horizontal = 12.dp, vertical = 7.dp),
                        color = Mint, fontSize = 10.sp, fontWeight = FontWeight.Bold)
                }
            }

            Surface(color = Panel, shape = RoundedCornerShape(22.dp), modifier = Modifier.fillMaxWidth()) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("YANGI EDIT", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Text("Video va audio fayllarini telefoningdan tanla.", color = Color.LightGray, fontSize = 13.sp)
                    OutlinedButton(
                        onClick = { videoPicker.launch(arrayOf("video/*")) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text(if (videoUri == null) "＋  VIDEO TANLASH" else "✓  VIDEO TANLANDI") }
                    OutlinedButton(
                        onClick = { audioPicker.launch(arrayOf("audio/*")) },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(14.dp)
                    ) { Text(if (audioUri == null) "♫  MUSIQA TANLASH" else "✓  MUSIQA TANLANDI") }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("EDIT DAVOMIYLIGI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf("15 soniya", "30 soniya", "45 soniya").forEach { option ->
                        FilterChip(
                            selected = duration == option,
                            onClick = { duration = option },
                            label = { Text(option) }
                        )
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("EDIT USLUBI", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                val styles = listOf("PHONK", "FUNK", "VELOCITY", "CINEMATIC", "FOOTBALL", "CAR EDIT", "ANIME")
                styles.chunked(3).forEach { rowStyles ->
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        rowStyles.forEach { item ->
                            FilterChip(
                                selected = style == item,
                                onClick = { style = item },
                                label = { Text(item, fontSize = 10.sp) }
                            )
                        }
                    }
                }
            }

            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("AI EDIT PROMPT", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.sp)
                OutlinedTextField(
                    value = prompt,
                    onValueChange = { prompt = it },
                    modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text("Masalan: tezkor zoom, flash va beat sync...") },
                    minLines = 2,
                    shape = RoundedCornerShape(16.dp)
                )
            }

            Button(
                onClick = {
                    status = when {
                        videoUri == null -> "Avval video tanlang."
                        audioUri == null -> "Avval musiqa tanlang."
                        else -> "Loyiha sozlandi: $style • $duration. Hozircha bu beta media tanlash va edit rejasini sinash uchun; haqiqiy render/AI tahlili keyingi buildda qo‘shiladi."
                    }
                },
                modifier = Modifier.fillMaxWidth().height(56.dp),
                shape = RoundedCornerShape(16.dp)
            ) {
                Text("EDIT LOYIHASINI TAYYORLASH", fontWeight = FontWeight.Bold)
            }

            Surface(color = Color(0xFF1C2130), shape = RoundedCornerShape(16.dp)) {
                Row(Modifier.padding(14.dp), verticalAlignment = Alignment.Top) {
                    Text("✦", color = Mint, fontSize = 20.sp, modifier = Modifier.padding(end = 10.dp))
                    Column {
                        Text("HOLAT", color = Mint, fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        Text(status, color = Color.White, fontSize = 13.sp)
                    }
                }
            }
            Text(
                "BETA 0.1 • Hozircha haqiqiy video eksporti va online generativ AI yo‘q. Keyingi bosqichda beat tahlili va render qo‘shiladi.",
                color = Color.Gray, fontSize = 11.sp
            )
        }
    }
}
