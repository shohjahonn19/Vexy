# VEXY AI — Android Beta

A native Kotlin + Jetpack Compose starter for a free-first video-editing app.

## Beta 0.1 currently includes
- Dark editor UI
- Android system pickers for video and audio
- 15 / 30 / 45-second duration options
- Phonk, Funk, Velocity, Cinematic, Football, Car Edit, Anime presets
- Prompt field and edit-plan status feedback
- GitHub Actions workflow to compile and upload a debug APK

## Not implemented yet
This beta is a testable UI foundation. It does **not** yet render a final edited video, detect music beats, apply real transitions, or connect to a generative AI provider. Those features must be implemented and tested before calling it a professional editor.

## Build
Open in Android Studio with JDK 17 and Android SDK 35, or use GitHub Actions. The workflow uploads `app-debug.apk` as an artifact when the build succeeds.
